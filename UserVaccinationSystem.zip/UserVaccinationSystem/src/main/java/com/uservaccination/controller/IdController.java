package com.uservaccination.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.uservaccination.exception.DuplicateAdharNoException;
import com.uservaccination.exception.InvalidInputException;
import com.uservaccination.exception.RecordNotFoundException;
import com.uservaccination.model.IdVerification;
import com.uservaccination.service.IdService;

@RestController
@CrossOrigin(origins="http://localhost:4202")
@RequestMapping("/id")
public class IdController {

	@Autowired
	private IdService idService;
	
	
	//http://localhost:8089/VaccinationApp/id/save
	@PostMapping(value="/save",consumes="application/json",produces="application/json")
	public ResponseEntity<IdVerification> saveId(@RequestBody IdVerification idVerification)throws InvalidInputException, DuplicateAdharNoException{
		IdVerification id=idService.createId(idVerification);
		if(id.getAdhaarNo()>0) {
			return ResponseEntity.ok(idVerification);
		}
	throw new DuplicateAdharNoException(" Id Exist ");
		
		
		
		
	}
	
	
	//http://localhost:8089/VaccinationApp/id/read
	@GetMapping(value="/read",produces="application/json")
	public ResponseEntity<List<IdVerification>> getAllId(){
		List<IdVerification> getAll=idService.getAllId();
		if(getAll.isEmpty()) {
			return new ResponseEntity("Sorry! Id not available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<IdVerification>>(getAll, HttpStatus.OK);
	}
	
	//http://localhost:8089/VaccinationApp/id/delete/{adhaarNo}
	@DeleteMapping(value="/delete/{adhaarNo}")
	public ResponseEntity<List<IdVerification>> deleteId(@PathVariable ("adhaarNo") Long adhaarNo)throws RecordNotFoundException,InvalidInputException{
		if(adhaarNo<=0) {
			throw new InvalidInputException("Invalid Input");
		}
		List<IdVerification> delete=idService.deleteId(adhaarNo);
		return new ResponseEntity<List<IdVerification>>(delete, HttpStatus.OK);
	}
	
	//http://localhost:8089/VaccinationApp/id/getById/{adhaarNo}
	@GetMapping("/getById/{adhaarNo}")
	public ResponseEntity<IdVerification> getByAdharNo(@PathVariable ("adhaarNo") Long adhaarNo) 
			throws DuplicateAdharNoException, InvalidInputException,RecordNotFoundException{
		if(adhaarNo<=0) {
			throw new InvalidInputException("Invalid Input");
		}
		IdVerification id=idService.getByAdharId(adhaarNo);
		
		return new ResponseEntity<IdVerification>(id,HttpStatus.OK);
	}
	
	//http://localhost:8089/VaccinationApp/id/update
	@PutMapping("/update/{adhaarNo}")
	public  ResponseEntity<List<IdVerification>> updateId(@PathVariable ("adhaarNo") Long adhaarNo, @RequestBody IdVerification idVerification)throws RecordNotFoundException{
		
		List<IdVerification> id=idService.updateId(idVerification, adhaarNo);
		if(id.isEmpty())
		{
			return new ResponseEntity("Sorry! Id not available!", 
					HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<List<IdVerification>>(id, HttpStatus.OK);
	}
	
	
	/*
	 * @PutMapping("/update") public ResponseEntity<List<IdVerification>>
	 * updateId(@RequestBody IdVerification idVerification){
	 * 
	 * List<IdVerification> id=idService.updateId(idVerification); if(id.isEmpty())
	 * { return new ResponseEntity("Sorry! Id not available!",
	 * HttpStatus.NOT_FOUND); }
	 * 
	 * return new ResponseEntity<List<IdVerification>>(id, HttpStatus.OK); }
	 */
	
	
	//http://localhost:8089/VaccinationApp/id/find/{panNo}
	@GetMapping("/find/{panNo}")
	public ResponseEntity<List<IdVerification>> findByPanNo(@PathVariable ("panNo") String panNo){
		List<IdVerification> name=idService.findByName(panNo);
		if(name.isEmpty()|| name==null) {
			return new ResponseEntity("Sorry PanNo not available",HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<List<IdVerification>>(name,HttpStatus.OK);
	}

}

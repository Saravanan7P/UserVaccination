package com.uservaccination.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.uservaccination.exception.InvalidInputException;
import com.uservaccination.model.Vaccine;
import com.uservaccination.service.VaccineService;


@RestController
@CrossOrigin

public class VaccineController {

	@Autowired
	private VaccineService vaccineService;
	
	//http://localhost:6060/VaccinationApp/vaccinationsys/vaccine/addnewvaccine
	@PostMapping("/vaccine/addnewvaccine")
	public Vaccine saveVaccine(@RequestBody Vaccine vaccine) {
		return vaccineService.saveVaccine(vaccine);
			}
	
	//http://localhost:6060/VaccinationApp/vaccinationsys/vaccine/listvaccine
	@GetMapping("/vaccine/listvaccine")
	public List<Vaccine> getAllVaccines(){
		return vaccineService.getAllVaccine();
	}
	
	//http://localhost:6060/VaccinationApp/vaccinationsys/vaccine/3
	@GetMapping("/vaccine/{vaccineId}")
	public ResponseEntity<Vaccine> getVaccineById(@PathVariable int vaccineId){
		if(vaccineId <= 0) {
			throw new InvalidInputException(vaccineId+" is not a valid Vaccine ID");
		}
		Vaccine vaccine = vaccineService.getVaccineByid(vaccineId);
		return new ResponseEntity<Vaccine>(vaccine,HttpStatus.OK);

	}

	
	//http://localhost:6060/VaccinationApp/vaccinationsys/removevaccine/3
	@DeleteMapping("/removevaccine/{vaccineId}")
	public String deleteVaccine(@PathVariable Integer vaccineId) {
		if(vaccineId<=0) {
			throw new InvalidInputException(vaccineId+" is not a valid Vaccine ID");
		}
		vaccineService.deleteVaccine(vaccineId);
		return "Vaccine Deleted Successfully";
	}
	
	//http://localhost:6060/VaccinationApp/vaccinationsys/updatevaccine/2
	@PutMapping("/updatevaccine/{vaccineId}")
	public ResponseEntity<Vaccine> updateVaccine(@PathVariable("vaccineId")int vaccineId,
			@RequestBody Vaccine vaccine){
		if(vaccineId<=0) {
			throw new InvalidInputException(vaccineId+" is not a valid Vaccine ID");
		}
		Vaccine updatedvaccine = vaccineService.updateVaccine(vaccineId, vaccine);
		return ResponseEntity.ok(updatedvaccine);
	}
	
	
}

package com.uservaccination.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.uservaccination.exception.InvalidInputException;
import com.uservaccination.model.VaccinationCentre;
import com.uservaccination.service.VaccinationCentreService;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping(value="/vaccinationcentre")
public class VaccinationCentreController {

	@Autowired
	VaccinationCentreService vacService;
	
	@PostMapping("/addnew") //http://localhost:6061/vaccinationcentre/addnew
	public String addVaccinationCentre(@RequestBody VaccinationCentre vCentre) {
		return vacService.saveVaccinationCentre(vCentre);
	}
	@GetMapping("/view")  //http://localhost:6061/vaccinationcentre/view
    public List<VaccinationCentre> findAllVaccinationCentre(){
    	return vacService.getAllVaccinationCentre();
    }
	@GetMapping("/view/{centreId}")
    public VaccinationCentre findAllVaccinationCentreById(@PathVariable Long centreId){
    	return vacService.getVaccinationCentreById(centreId);
    }
	@DeleteMapping("/delete/{centreId}")  //http://localhost:6061/vaccinationcentre/delete
	public String deleteVaccinatioCentre(@PathVariable Long centreId) {
		if(centreId<=0) {
			throw new InvalidInputException("id " +centreId+" not found");
		}
		return vacService.deleteVaccinationCentre(centreId);
	}
	@PutMapping("/update/{centreId}") 
	public VaccinationCentre updateVaccinationCentre(@PathVariable(value="centreId")Long centreId,
			@RequestBody VaccinationCentre vacCentre) {
		return vacService.updateVaccinationCentre(centreId, vacCentre);
	}
}

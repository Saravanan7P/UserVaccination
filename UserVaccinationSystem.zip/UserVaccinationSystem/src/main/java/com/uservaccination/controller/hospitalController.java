package com.uservaccination.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.uservaccination.exception.InvalidInputException;
import com.uservaccination.model.Hospital;
import com.uservaccination.service.HospitalService;

@CrossOrigin
@RestController
@RequestMapping(value="/VaccApp")
public class hospitalController{
	
	@Autowired
	private HospitalService hospitalService;
	
	@GetMapping(value = "/hospital")
	public List<Hospital> getAllHospital() {
	return hospitalService.getAllHospital();
	}

	@PostMapping(value = "/addhospital", consumes = "application/json", produces = "application/json")
	ResponseEntity<Hospital> savecenter(@RequestBody Hospital center) {
		Hospital h1 = hospitalService.savecenter(center);
		System.out.println("Center has newly added");
		return ResponseEntity.ok(center);
	}
	
	//http://localhost:5001/VaccApp/hospitals/hospital/{pincode} ;
	@GetMapping(path="/hospital/{pincode}")
	/*public ResponseEntity<List<Hospital>> getHospitalBypincode(@PathVariable ("pincode")int pincode){
		List<Hospital> center = hospitalService.getHospitalBypincode(pincode);
		if(pincode <= 0) {
			throw new InvalidInputException(pincode+" is a not a Valid Pincode");
		}
		return new ResponseEntity<List<Hospital>>(center, HttpStatus.OK);
	}*/
	public ResponseEntity<List<Hospital>> findHospitalBypincode(@PathVariable("pincode") int pincode) {
		List<Hospital> center = hospitalService.findHospitalBypincode(pincode);
		if (pincode <= 0) {
			throw new InvalidInputException(pincode + " is a not a Valid Pincode");
		}
		return new ResponseEntity<List<Hospital>>(center, HttpStatus.OK);
	}
	
	
	//http://localhost:5001/VaccApp/hospitals/deleteproduct/{Id}
	@DeleteMapping("/hospital/{hospitalId}")
	public void deleteHospital(@PathVariable int hospitalId) {
		if (hospitalId <= 0) {
			throw new InvalidInputException(hospitalId + " is a not a Valid Id");
		}
		hospitalService.deleteHospital(hospitalId);

	}
		//http://localhost:5001/VaccApp
		@PutMapping(path="/updatehospital/{hospitalId}", consumes = "application/json")
		public ResponseEntity<Hospital> updateHospital(@PathVariable("hospitalId") int hospitalId, @RequestBody Hospital center) {
			Hospital hospital = hospitalService.updateHospital(hospitalId, center);
			return ResponseEntity.ok(hospital);
		}
		@GetMapping("/gethospital/{hospitalId}")
		public ResponseEntity<Hospital> getHospitalById(@PathVariable int hospitalId){
			Hospital hospital = hospitalService.getHospitalById(hospitalId);
			 return new ResponseEntity<Hospital>(hospital,HttpStatus.OK);
		}

	}



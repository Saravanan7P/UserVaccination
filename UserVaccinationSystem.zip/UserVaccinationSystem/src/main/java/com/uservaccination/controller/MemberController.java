package com.uservaccination.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.uservaccination.exception.InvalidInputException;
import com.uservaccination.model.Member;
import com.uservaccination.service.MemberService;


@CrossOrigin
@RestController
@RequestMapping(value="/membercon")
public class MemberController {

	@Autowired
	private MemberService mService;
	//http://localhost:6070/VaccinationApp/membercon/member/addnew
	@PostMapping("/member/addnew")
	public Member saveMember(@RequestBody Member member) {
		return mService.saveMember(member);
	}
	//http://localhost:6070/VaccinationApp/membercon/member/viewlist
	@GetMapping("/member/viewlist")
    public List<Member> findAllMember(){
    	return mService.getAllMembers();
    }
	//http://localhost:6070/VaccinationApp/membercon/member/3
	@GetMapping("/member/{memberId}")
	public ResponseEntity<Member> getMemberById(@PathVariable int  memberId){
		if(memberId <= 0) {
			throw new InvalidInputException(memberId+" is not a valid Vaccine ID");
		}
		Member member = mService.getMemberByid(memberId);
		return new ResponseEntity<Member>(member,HttpStatus.OK);

	}
	//http://localhost:6070/VaccinationApp/membercon/update/3
	@PutMapping("/update/{memberId}") 
	public Member updateMember(@PathVariable(value="memberId")Integer memberId,
			@RequestBody Member member) {
		return mService.updateMember(memberId, member);
	}
	//http://localhost:6070/VaccinationApp/membercon/delete/3
	@DeleteMapping("/delete/{memberId}")
	public void deleteMember(@PathVariable int memberId) {
		 mService.deleteMember(memberId);
	}
	
}

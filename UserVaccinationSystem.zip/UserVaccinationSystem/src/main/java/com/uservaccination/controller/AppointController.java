package com.uservaccination.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.uservaccination.exception.InvalidInputException;
import com.uservaccination.model.Appoint;
import com.uservaccination.service.AppointService;

@CrossOrigin
@RestController
@RequestMapping("/appoint")
public class AppointController
{
	
	@Autowired
    private AppointService bookingService;
	
	@GetMapping(value="/list")
	public List<Appoint> getAllAppointment() {
		return bookingService.getAllAppointment();
	}
	@PostMapping(value="/appointment/addappointment",consumes = "application/json" , produces = "application/json")
	ResponseEntity<Appoint> saveappoint(@RequestBody Appoint appoint) {
		Appoint id = bookingService.saveappoint(appoint);
		System.out.println("Center has newly added");
		return ResponseEntity.ok(appoint);
	}
	@DeleteMapping("/deleteappointment/{appointmentId}")
	public void deleteAppointment(@PathVariable int appointmentId) {
		if (appointmentId <= 0) {
			throw new InvalidInputException(appointmentId + " is a not a Valid Id");
		}
		System.out.println("Center details have deleted sucessfully");
		bookingService.deleteAppointment(appointmentId);
	}
	@PutMapping(path = "/updappoint/{appointmentId}", consumes = "application/json")
	public ResponseEntity<Appoint> updateAppointment(@PathVariable("appointmentId") int appointmentId, @RequestBody Appoint appoint) {
		if (appointmentId <= 0) {
			throw new InvalidInputException(appointmentId + " is a not a Valid Id");
		}
		Appoint a1 = bookingService.updateAppointment(appointmentId, appoint);
		System.out.println("Center details have updated sucessfully");
		return ResponseEntity.ok(a1);
	}
	@GetMapping("/getappoint/{appointmentId}")
	public ResponseEntity<Appoint> findAppointmentById(@PathVariable int appointmentId){
		Appoint appoint = bookingService.findAppointmentById(appointmentId);
		 return new ResponseEntity<Appoint>(appoint,HttpStatus.OK);
	}
}

package com.uservaccination.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.uservaccination.exception.InvalidInputException;
import com.uservaccination.exception.RecordNotFoundException;
import com.uservaccination.model.Register;
import com.uservaccination.service.RegisterService;

@CrossOrigin
@RestController
public class RegisterController {
	
	@Autowired
	
	RegisterService registerservice;
	
	// GET-Edit User Information
	//http://localhost:5000/VaccinationApp/register/registerdetails//
	@GetMapping("/register/registerdetails")
	public List<Register> getAllRegister(){
		return registerservice.getAllregisterdetails();
	
	}
	//get the Placement detail using id,if id value <= 0 exception will be thrown//
	@GetMapping("/register/{registerId}")
	public ResponseEntity<Register> getRegisterById(@PathVariable int registerId) {
		if(registerId <=0) {
			
			throw new InvalidInputException(registerId+"is not a valid Register ID");
		}
		Register register =registerservice.getRegisterById(registerId);
		return new ResponseEntity<Register>(register,HttpStatus.OK);
	}
	
	
	//POST-Stores Data to DataBase//
	//http://localhost:5000/VaccinationApp/register/add//
	@PostMapping("/register/add")
	public Register saveRegister (@RequestBody Register register) {
		System.out.println(register);
		return registerservice.saveRegister(register);
	}
	
	//DELETE-Delete Information//
	//http://localhost:5000/VaccinationApp/register/2//
	@DeleteMapping("/register/{registerId}")
	public String deleteRegister(@PathVariable int registerId) {
		if(registerId <=0) {
			throw new InvalidInputException(registerId+"is not a Register ID");
			
		}
		registerservice.deleteRegister(registerId);
		return "Delete successfully" ;
		
	}
	
	//PUT-Update Information//
	//http://localhost:5000/VaccinationApp/register/3//
	@PutMapping("/register/{id}")
	public ResponseEntity <Register> updateId (@PathVariable(value ="id") int registerId,@RequestBody Register register){
		if(registerId <=0) {
			throw new InvalidInputException(registerId +"is not a valid Register ID");
			
		}
		Register updatedregister =registerservice.updateRegister(registerId,register);
		return ResponseEntity.ok(updatedregister);
	}
	

	
	//http://localhost:5000/VaccinationApp/login//
	@PostMapping("/login")
	public Register registerLogin(@RequestBody Register register) {
		String tempFirstName=register.getFirstName();
		String tempPassword=register.getPassword();
		Register registerObj =null;
		if(tempFirstName != null && tempPassword !=null) {
			registerObj = registerservice.fetchRegisterByFirstNameAndPassword(tempFirstName, tempPassword);
		}
	if(registerObj ==null) {
		throw new RecordNotFoundException("Bad Credentials");
	}
	return registerObj;
}
}


package com.uservaccination.service;

import java.util.List;

import com.uservaccination.exception.RecordNotFoundException;
import com.uservaccination.model.IdVerification;




public interface IdService {

	public IdVerification createId(IdVerification idVerification);
	
	public List<IdVerification> getAllId();
	
	public List<IdVerification> deleteId(Long adhaarNo) throws RecordNotFoundException;
	
	public IdVerification getByAdharId(Long adhaarNo) throws RecordNotFoundException;
	
	public List<IdVerification> updateId(IdVerification idVerification,Long adhaarNo) throws RecordNotFoundException;
	
	public List<IdVerification> findByName(String panNo);
	
	
}

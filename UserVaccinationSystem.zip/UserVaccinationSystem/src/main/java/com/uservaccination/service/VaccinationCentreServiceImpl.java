package com.uservaccination.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uservaccination.exception.RecordNotFoundException;
import com.uservaccination.model.VaccinationCentre;
import com.uservaccination.repo.VaccinationCentreRepo;

@Service
public class VaccinationCentreServiceImpl implements VaccinationCentreService {

	@Autowired
	private VaccinationCentreRepo vacRepo;

	@Override
	public String saveVaccinationCentre(VaccinationCentre vCentre) {
		
		 vacRepo.save(vCentre);
	
		 return "{\"status\": \"'success'\"}";
	}

	@Override
	public List<VaccinationCentre> getAllVaccinationCentre() {
		return vacRepo.findAll();
	}

	@Override
	public VaccinationCentre getVaccinationCentreById(Long centreId) {
		return vacRepo.findById(centreId)
				.orElseThrow(() -> new RecordNotFoundException("No centre available with id :" + centreId));
	}

	@Override
	public String deleteVaccinationCentre(Long centreId) {
		String status = "";
		vacRepo.deleteById(centreId);

		if (centreId != null) {
			status = "success";
		} else {
			status = "failed";
		}

		return "{\"status\": \"'" + status + "'\"}";
	}

	@Override
	public VaccinationCentre updateVaccinationCentre(Long centreId, VaccinationCentre vCentre) {
//		String status = "";
		VaccinationCentre existingVaccinationCentre = vacRepo.findById(vCentre.getCentreId())
				.orElseThrow(() -> new RecordNotFoundException("failed"));
		existingVaccinationCentre.setCentreId(vCentre.getCentreId());
		existingVaccinationCentre.setCentreName(vCentre.getCentreName());
		existingVaccinationCentre.setAddress(vCentre.getAddress());
		existingVaccinationCentre.setCity(vCentre.getCity());
		existingVaccinationCentre.setState(vCentre.getState());
		existingVaccinationCentre.setPincode(vCentre.getPincode());

		
		return vacRepo.save(existingVaccinationCentre);
	}
}

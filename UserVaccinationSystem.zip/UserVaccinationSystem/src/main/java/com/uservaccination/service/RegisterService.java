package com.uservaccination.service;

import java.util.List;

import com.uservaccination.model.Register;

public interface RegisterService {
public List<Register>getAllregisterdetails();
public Register saveRegister(Register register);
public void deleteRegister( int registerId);
public Register updateRegister(int registerId,Register register);
public Register getRegisterById(int registerId);

//public Register register(String firstName,String password);//
Register fetchRegisterByFirstNameAndPassword(String firstName, String password);

}

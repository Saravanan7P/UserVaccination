package com.uservaccination.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uservaccination.exception.RecordNotFoundException;
import com.uservaccination.model.Appoint;
import com.uservaccination.repo.AppointRepo;

@Service
public class AppointServiceImpl implements AppointService{
	
	@Autowired
	AppointRepo appointrepo;
	
	@Override
	public List<Appoint> getAllAppointment() {
		return appointrepo.findAll();
	}
	
	@Override
	public Appoint saveappoint(Appoint appoint) {
		return appointrepo.save(appoint);
	}
	@Override
	public void deleteAppointment(int appointmentId) {
		appointrepo.deleteById(appointmentId);

	}
	@Override
	public Appoint updateAppointment(int appointmentId, Appoint appoint) {
		Appoint book = findAppointmentById(appointmentId);
		book.setName(appoint.getName());
		book.setMobileNumber(appoint.getMobileNumber());
		book.setDate(appoint.getDate());
		book.setAadharNumber(appoint.getAadharNumber());
		book.setDose(appoint.getDose());
		book.setVaccine(appoint.getVaccine());
		book.setHospital(appoint.getHospital());
		return appointrepo.save(appoint);
	}
	@Override
	public Appoint findAppointmentById(int appointmentId) {
		return appointrepo.findById(appointmentId).orElseThrow(() -> new RecordNotFoundException("Appointment Id not found"));
	}

}

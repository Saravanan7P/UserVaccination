package com.uservaccination.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uservaccination.exception.RecordNotFoundException;
import com.uservaccination.model.Hospital;
import com.uservaccination.repo.HospitalRepo;

@Service
public class HospitalServiceImpl implements HospitalService {
	
	@Autowired
	HospitalRepo hosprepo;

	@Override
	public List<Hospital> getAllHospital() {
		return hosprepo.findAll();

	}

	@Override
	public Hospital savecenter(Hospital center) {
		return hosprepo.save(center);
	}

	/*@Override
	public List<Hospital> getHospitalBypincode(int pincode) {
		List<Hospital> center=hosprepo.getHospitalBypincode(pincode);
		return center;
	}*/
	@Override
	public List<Hospital> findHospitalBypincode(int pincode) {
		List<Hospital> center = hosprepo.findHospitalBypincode(pincode);
		return center;
	}

	@Override
	public void deleteHospital(int hospitalId) {
		Hospital hosp = getHospitalById(hospitalId);
		hosprepo.delete(hosp);
	}

	@Override
	public Hospital updateHospital(int hospitalId, Hospital center) {
		Hospital hospital = getHospitalById(hospitalId);
		hospital.setHospital(center.getHospital());
		hospital.setPincode(center.getPincode());
		return hosprepo.save(hospital);
	}

	/*@Override
	public Hospital getHospitalById(int Id) {
		return hosprepo.findById(Id).orElseThrow(() -> new RecordNotFoundException("Hospital Id not found"));
	}*/
	@Override
	public Hospital getHospitalById(int hospitalId) {
		return hosprepo.findById(hospitalId).orElseThrow(() -> new RecordNotFoundException("Hospital Id not found"));
	}
}
	


	
	





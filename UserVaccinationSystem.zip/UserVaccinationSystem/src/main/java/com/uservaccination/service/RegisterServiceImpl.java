package com.uservaccination.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uservaccination.exception.RecordNotFoundException;
import com.uservaccination.model.Register;
import com.uservaccination.repo.RegisterRepository;


@Service
public class RegisterServiceImpl implements RegisterService {
	
@Autowired

RegisterRepository registerRepo;
	@Override
	public List<Register> getAllregisterdetails() {
		
	return registerRepo.findAll();
	}
	@Override
	public Register saveRegister(Register register) {
		
		return registerRepo.save(register);
	}
	@Override
	public void deleteRegister(int registerId) {
		registerRepo.deleteById(registerId);
		
	}
	@Override
	public Register updateRegister(int registerId, Register register) {
		Register r1 = getRegisterById(registerId);
		r1.setAddress(register.getAddress());
		r1.setPincode(register.getPincode());
		r1.setCity(register.getCity());
		r1.setFirstName(register.getFirstName());
		r1.setLastName(register.getLastName());
		r1.setState(register.getState());
		r1.setGender(register.getGender());
		return registerRepo.save(r1);
		
	}
	@Override
	public Register getRegisterById(int registerId) {
		
		return registerRepo.findById(registerId).orElseThrow(() -> new RecordNotFoundException("Register Id not found"));
		
	}
	

	@Override
	
	public Register fetchRegisterByFirstNameAndPassword(String firstName, String password) {
		// TODO Auto-generated method stub
		return registerRepo.findByFirstNameAndPassword(firstName, password);
	}
	
	/*public Register register(String firstName, String password) {
		Register register1=registerRepo.findByfirstNameAndPassword(firstName, password);
		return register1;
	}*/
	
	
}
	
	

	
		



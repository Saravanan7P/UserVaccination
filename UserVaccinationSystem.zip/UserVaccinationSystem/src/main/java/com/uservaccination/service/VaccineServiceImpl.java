package com.uservaccination.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uservaccination.exception.RecordNotFoundException;
import com.uservaccination.model.Vaccine;
import com.uservaccination.repo.VaccineRepository;

@Service
public class VaccineServiceImpl implements VaccineService{

	@Autowired
	private VaccineRepository vaccineRepo;
	
	@Override
	public Vaccine saveVaccine(Vaccine vaccine) {
		return vaccineRepo.save(vaccine);
	}

	@Override
	public List<Vaccine> getAllVaccine() {
		return vaccineRepo.findAll();
	}

	@Override
	public Vaccine getVaccineByid(int vaccineId) {
		return vaccineRepo.findById(vaccineId).orElseThrow(() -> new RecordNotFoundException("Vaccine Id not found"));
	}

	@Override
	public Vaccine updateVaccine(int vaccineId, Vaccine vaccine) {
		Vaccine v1 = getVaccineByid(vaccineId);
		v1.setVaccineName(vaccine.getVaccineName());
		v1.setDescription(vaccine.getDescription());
		v1.setQuantity(vaccine.getQuantity());
		v1.setPrice(vaccine.getPrice());
		return vaccineRepo.save(v1);
	}

	@Override
	public void deleteVaccine(int vaccineId) {
		Vaccine vaccine = getVaccineByid(vaccineId);
		vaccineRepo.delete(vaccine);		
	}

}

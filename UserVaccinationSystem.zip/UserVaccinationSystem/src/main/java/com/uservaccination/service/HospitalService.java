package com.uservaccination.service;


import java.util.List;

import com.uservaccination.model.Hospital;


public interface HospitalService  {
	
	 public List<Hospital> getAllHospital();
	
	 public Hospital savecenter(Hospital center);
	  
//	 public List<Hospital> getHospitalBypincode(int pincode);
	 
	 public List<Hospital> findHospitalBypincode(int pincode);
	 
	 public void deleteHospital(int hospitalId);
	 
	 public Hospital updateHospital(int hospitalId , Hospital center);
	 
//	 public Hospital getHospitalById(int Id);
	 
	 public Hospital getHospitalById(int hospitalId);


}

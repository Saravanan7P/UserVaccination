package com.uservaccination.service;

import java.util.List;

import com.uservaccination.model.Member;

public interface MemberService {
	
	public Member saveMember(Member member);
	
	public List<Member> getAllMembers();
	
	public Member getMemberByid(int memberId);
	
    public Member updateMember(Integer memberId,  Member member);
    
    public String deleteMember(int memberId );
}

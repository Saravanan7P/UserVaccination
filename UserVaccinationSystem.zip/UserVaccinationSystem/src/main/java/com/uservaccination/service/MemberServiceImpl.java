package com.uservaccination.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uservaccination.exception.RecordNotFoundException;
import com.uservaccination.model.Member;
import com.uservaccination.repo.MemberRepo;

@Service
public class MemberServiceImpl implements MemberService {
	
	@Autowired
	public MemberRepo mRepo;
	
	@Override
	public Member saveMember(Member member) {
	return mRepo.save(member);
	}
	
	@Override
	public List<Member> getAllMembers(){
		return mRepo.findAll();
	}
	
	@Override
	public Member updateMember(Integer memberId , Member member){
		Member oldMember = mRepo.findById(member.getMemberId()).orElse(member);
		oldMember.setDose1date(member.getDose1date());
		oldMember.setDose1status(member.getDose1status());
		oldMember.setDose2date(member.getDose2date());
		oldMember.setDose2status(member.getDose2status());
		oldMember.setVaccineName(member.getVaccineName());
		return mRepo.save(oldMember);
	}
	
	@Override
	public String deleteMember(int memberId) {
		mRepo.deleteById(memberId);
		return "removed member " +memberId ;
	}

	@Override
	public Member getMemberByid(int memberId) {
		return mRepo.findById(memberId).orElseThrow(()-> new RecordNotFoundException(memberId+" not found"));
	}
}

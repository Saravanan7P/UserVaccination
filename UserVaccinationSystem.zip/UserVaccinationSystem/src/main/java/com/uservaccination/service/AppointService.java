package com.uservaccination.service;

import java.util.List;

import com.uservaccination.model.Appoint;


public interface AppointService {
	
	public List<Appoint> getAllAppointment();
	
	public Appoint saveappoint(Appoint appoint);
	
	public void deleteAppointment(int appointmentId);
	 
	public Appoint updateAppointment(int appointmentId , Appoint appoint);
	
	public Appoint findAppointmentById(int appointmentId);

}

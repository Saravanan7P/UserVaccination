package com.uservaccination.service;

import java.util.List;

import com.uservaccination.model.Vaccine;

public interface VaccineService {

	public Vaccine saveVaccine(Vaccine vaccine);
	
	public List<Vaccine> getAllVaccine();
	
	public Vaccine getVaccineByid(int vaccineId);
	
	public Vaccine updateVaccine(int vaccineId,Vaccine vaccine);
	
	public void deleteVaccine(int vaccineId);
}

package com.uservaccination.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uservaccination.exception.RecordNotFoundException;
import com.uservaccination.model.IdVerification;
import com.uservaccination.repo.IdRepository;

@Service
public class IdVerificationImpl implements IdService {
   
	@Autowired
	private IdRepository idRepo;
	
	
	@Override
	public IdVerification createId(IdVerification idVerification) {
		  
	      return idRepo.save(idVerification);
	}


	@Override
	public List<IdVerification> getAllId() {
	    
		return idRepo.findAll();
	}


	@Override
	public List<IdVerification> deleteId(Long adhaarNo) throws RecordNotFoundException {
		IdVerification id=getByAdharId(adhaarNo);
		idRepo.delete(id);
		return idRepo.findAll();
	}


	@Override
	public IdVerification getByAdharId(Long adhaarNo) throws RecordNotFoundException{
		 return idRepo.findById(adhaarNo).orElseThrow(() -> 
		 new RecordNotFoundException("Record not found"));
			
			}
	


	@Override
	public List<IdVerification> updateId(IdVerification idVerification , Long adhaarNo) throws RecordNotFoundException {
		IdVerification id=getByAdharId(adhaarNo);
		id.setAdhaarNo(idVerification.getAdhaarNo());
		id.setPanNo(idVerification.getPanNo());
		idRepo.save(id);
		//IdVerification id=idRepo.saveAndFlush(idVerification);
		return idRepo.findAll();
	}


	@Override
	public List<IdVerification> findByName(String panNo) {
		List<IdVerification>name=idRepo.findByPanNo(panNo);
		return name;
	}


	
	

}

package com.uservaccination.service;


import java.util.List;

import com.uservaccination.model.VaccinationCentre;



public interface VaccinationCentreService {

	public String saveVaccinationCentre(VaccinationCentre vCentre);
	
	public List<VaccinationCentre> getAllVaccinationCentre();
	
	public VaccinationCentre getVaccinationCentreById(Long centreId);
	
	public String deleteVaccinationCentre(Long centreId);
	
	public VaccinationCentre updateVaccinationCentre(Long centreId, VaccinationCentre vCentre);
}

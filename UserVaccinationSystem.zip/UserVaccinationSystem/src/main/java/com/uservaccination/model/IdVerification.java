package com.uservaccination.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="id")
public class IdVerification {
	@Id
	@Column(name="adhar_No")
	private Long adhaarNo;
	
	@Column(name="pan_No")
	private String panNo;
	
	public IdVerification() {}

	public IdVerification(Long adhaarNo, String panNo) {
		super();
		this.adhaarNo = adhaarNo;
		this.panNo = panNo;
	}

	public Long getAdhaarNo() {
		return adhaarNo;
	}

	public void setAdhaarNo(Long adhaarNo) {
		this.adhaarNo = adhaarNo;
	}

	public String getPanNo() {
		return panNo;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	@Override
	public String toString() {
		return "IdVerification [adhaarNo=" + adhaarNo + ", panNo=" + panNo + "]";
	}

	
}

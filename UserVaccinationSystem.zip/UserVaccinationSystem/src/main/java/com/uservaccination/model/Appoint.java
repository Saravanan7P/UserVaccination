package com.uservaccination.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "appoint")
public class Appoint {
	
	@Id
	@Column(name = "id")
	private int appointmentId;
	
	@Column(name = "name")
	private String name;
	
	@Column(name = "hospital")
	private String hospital;
	
	@Column(name = "mobileno")
	private long mobileNumber;
	
	@Column(name = "aadhar")
	private String aadharNumber;
	
	@Column(name = "date")
	private Date date;
	
	@Column(name = "dose")
	private String dose;
	
	@Column(name = "vaccine")
	private String vaccine;
	

		public Appoint() {
		
	}


		public int getAppointmentId() {
			return appointmentId;
		}


		public void setAppointmentId(int appointmentId) {
			this.appointmentId = appointmentId;
		}


		public String getName() {
			return name;
		}


		public void setName(String name) {
			this.name = name;
		}


		public String getHospital() {
			return hospital;
		}


		public void setHospital(String hospital) {
			this.hospital = hospital;
		}


		public long getMobileNumber() {
			return mobileNumber;
		}


		public void setMobileNumber(long mobileNumber) {
			this.mobileNumber = mobileNumber;
		}


		public String getAadharNumber() {
			return aadharNumber;
		}


		public void setAadharNumber(String aadharNumber) {
			this.aadharNumber = aadharNumber;
		}


		public Date getDate() {
			return date;
		}


		public void setDate(Date date) {
			this.date = date;
		}


		public String getDose() {
			return dose;
		}


		public void setDose(String dose) {
			this.dose = dose;
		}


		public String getVaccine() {
			return vaccine;
		}


		public void setVaccine(String vaccine) {
			this.vaccine = vaccine;
		}


		@Override
		public String toString() {
			return "Appoint [appointmentId=" + appointmentId + ", name=" + name + ", hospital=" + hospital
					+ ", mobileNumber=" + mobileNumber + ", aadharNumber=" + aadharNumber + ", date=" + date + ", dose="
					+ dose + ", vaccine=" + vaccine + "]";
		}


		public Appoint(int appointmentId, String name, String hospital, long mobileNumber, String aadharNumber,
				Date date, String dose, String vaccine) {
			super();
			this.appointmentId = appointmentId;
			this.name = name;
			this.hospital = hospital;
			this.mobileNumber = mobileNumber;
			this.aadharNumber = aadharNumber;
			this.date = date;
			this.dose = dose;
			this.vaccine = vaccine;
		}
	
	


}

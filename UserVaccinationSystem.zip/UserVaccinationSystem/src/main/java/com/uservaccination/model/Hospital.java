package com.uservaccination.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Hospital")
public class Hospital {

	@Id
	@Column(name = "id")
	private int hospitalId;

	@Column(name = "pincode")
	private int pincode;

	@Column(name = "hospital")
	private String hospital;

	

	public int getHospitalId() {
		return hospitalId;
	}



	public void setHospitalId(int hospitalId) {
		this.hospitalId = hospitalId;
	}



	public int getPincode() {
		return pincode;
	}



	public void setPincode(int pincode) {
		this.pincode = pincode;
	}



	public String getHospital() {
		return hospital;
	}



	public void setHospital(String hospital) {
		this.hospital = hospital;
	}


	@Override
	public String toString() {
		return "Hospital [hospitalId=" + hospitalId + ", pincode=" + pincode + ", hospital=" + hospital + "]";
	}
	
	public Hospital(int hospitalId, int pincode, String hospital) {
		super();
		this.hospitalId = hospitalId;
		this.pincode = pincode;
		this.hospital = hospital;
	}



	public Hospital() {

	}

}

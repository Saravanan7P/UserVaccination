package com.uservaccination.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name ="member")
public class Member {
    
	@Id
	@Column(name ="member_id")
	int memberId;
	@Column(name="dose1status")
	String dose1status;
	@Column(name="dose2status")
	String dose2status;
	@Column(name="dose1date")
	String dose1date;
	@Column(name="dose2date")
	String dose2date;
	@Column(name="vac_name")
	String vaccineName;

	public Member() {
	}

	public Member(int memberId, String dose1status, String dose2status, String dose1date, String dose2date,
			String vaccineName) {
		super();
		this.memberId = memberId;
		this.dose1status = dose1status;
		this.dose2status = dose2status;
		this.dose1date = dose1date;
		this.dose2date = dose2date;
		this.vaccineName = vaccineName;
	}

	public int getMemberId() {
		return memberId;
	}

	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}



	public String getDose1status() {
		return dose1status;
	}



	public void setDose1status(String dose1status) {
		this.dose1status = dose1status;
	}



	public String getDose2status() {
		return dose2status;
	}



	public void setDose2status(String dose2status) {
		this.dose2status = dose2status;
	}



	public String getDose1date() {
		return dose1date;
	}

	public void setDose1date(String dose1date) {
		this.dose1date = dose1date;
	}

	public String getDose2date() {
		return dose2date;
	}

	public void setDose2date(String dose2date) {
		this.dose2date = dose2date;
	}

	public String getVaccineName() {
		return vaccineName;
	}

	public void setVaccineName(String vaccineName) {
		this.vaccineName = vaccineName;
	}

	
}
package com.uservaccination.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="vaccinationcentre")
public class VaccinationCentre {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name ="centre_id")
	Long centreId;
	@Column(name ="centre_name")
	String centreName;
	@Column(name ="address")
	String address;
	@Column(name ="city")
	String city;
	@Column(name ="state")
	String state;
	@Column(name ="pincode")
	String pincode;
	
	public VaccinationCentre (){
	}

	public VaccinationCentre(Long centreId, String centreName, String address, String city, String state,
			String pincode) {
		super();
		this.centreId = centreId;
		this.centreName = centreName;
		this.address = address;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
	}

	public Long getCentreId() {
		return centreId;
	}

	public void setCentreId(Long centreId) {
		this.centreId = centreId;
	}

	public String getCentreName() {
		return centreName;
	}

	public void setCentreName(String centreName) {
		this.centreName = centreName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	@Override
	public String toString() {
		return "VaccinationCentre [centreId=" + centreId + ", centreName=" + centreName + ", address=" + address
				+ ", city=" + city + ", state=" + state + ", pincode=" + pincode + "]";
	}


	
}

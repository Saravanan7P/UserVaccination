package com.uservaccination.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.uservaccination.model.Register;

@Repository
public interface RegisterRepository extends JpaRepository<Register,Integer> {

	//Register findByfirstNameAndPassword(String firstName, String password);//
 public Register findByFirstNameAndPassword(String firstName, String password);

}

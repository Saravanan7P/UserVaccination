package com.uservaccination.repo;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.uservaccination.model.VaccinationCentre;

@Repository
public interface VaccinationCentreRepo extends JpaRepository<VaccinationCentre, Long>{

}

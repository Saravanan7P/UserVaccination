package com.uservaccination.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.uservaccination.model.Hospital;

@Repository
public interface HospitalRepo extends JpaRepository<Hospital, Integer> {
	
//	public List<Hospital> getHospitalBypincode(@Param("pincode") int pincode);
	
	/*@Query("SELECT hosp FROM Hospital hosp  WHERE hosp.pincode>=:pincode") // JPQL
	public List<Hospital> getHospitalBypincode(@Param("pincode") int pincode);*/
	
	public List<Hospital> findHospitalBypincode(@Param("pincode") int pincode);

}

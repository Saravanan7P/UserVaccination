package com.uservaccination.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.uservaccination.model.IdVerification;

@Repository
public interface IdRepository extends JpaRepository<IdVerification, Long> {
	public List<IdVerification> findByPanNo(@Param("panNo") String panNo);

}

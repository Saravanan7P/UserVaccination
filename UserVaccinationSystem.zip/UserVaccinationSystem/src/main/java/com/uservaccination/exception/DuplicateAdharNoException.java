package com.uservaccination.exception;

public class DuplicateAdharNoException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//public static final long serialVersionUId=1L;
	
	public DuplicateAdharNoException(String exception) {
		super(exception);
	}

}

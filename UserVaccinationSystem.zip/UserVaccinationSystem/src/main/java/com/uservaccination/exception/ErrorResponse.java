package com.uservaccination.exception;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonFormat;

public class ErrorResponse {
	
	private String message;
	private int status;
	
	private String errorResponse;
	private String errorCode;
	
	@JsonFormat(shape=JsonFormat.Shape.STRING,pattern="dd:MM:yyyy hh:mm:ss")
	private LocalDateTime timeStamp;
	
	public ErrorResponse() {
	}
	
	public ErrorResponse(String message, int status) {
		super();
		this.message = message;
		this.status = status;
	}
	
	

	public ErrorResponse(String message, int status, String errorResponse, String errorCode, LocalDateTime timeStamp) {
		super();
		this.message = message;
		this.status = status;
		this.errorResponse = errorResponse;
		this.errorCode = errorCode;
		this.timeStamp = timeStamp;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getErrorResponse() {
		return errorResponse;
	}

	public void setErrorResponse(String errorResponse) {
		this.errorResponse = errorResponse;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public LocalDateTime getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(LocalDateTime timeStamp) {
		this.timeStamp = timeStamp;
	}
	
	
}

package com.uservaccination;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserVaccinationSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
